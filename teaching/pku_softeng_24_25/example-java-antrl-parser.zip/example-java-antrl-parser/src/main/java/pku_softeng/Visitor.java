package pku_softeng;

public interface Visitor {
    public void visit(Add a);
    public void visit(Sub s);
    public void visit(Number n);    
}
