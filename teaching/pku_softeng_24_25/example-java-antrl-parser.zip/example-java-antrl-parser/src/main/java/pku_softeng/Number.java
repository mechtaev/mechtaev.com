package pku_softeng;

public class Number implements Expression {
    int value;
    public Number(int value) {
        this.value = value;
    }
    public int calculate() {
        return value;
    }
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);        
    }

    @Override
    public void accept(MemoVisitor visitor) {
        if (visitor.alreadyVisited(this)) {
            visitor.visitAgain(this);
        } else {
            visitor.visit(this);
        }        
    }


}
