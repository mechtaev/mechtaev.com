package pku_softeng;

public class Sub implements Expression {
    Expression left;
    Expression right;
    public Sub(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }
    public int calculate() {
        return left.calculate() - right.calculate();
    }
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);        
    }

    @Override
    public void accept(MemoVisitor visitor) {
        if (visitor.alreadyVisited(this)) {
            visitor.visitAgain(this);
        } else {
            visitor.visit(this);
        }
    }


}
