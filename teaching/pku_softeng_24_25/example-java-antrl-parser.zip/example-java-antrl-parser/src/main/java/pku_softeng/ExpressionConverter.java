package pku_softeng;


public class ExpressionConverter extends ExpressionGrammarBaseVisitor<Expression> {

    @Override
    public Expression visitOpExpr(ExpressionGrammarParser.OpExprContext ctx) {
        Expression left = visit(ctx.left);
        Expression right = visit(ctx.right);
        String op = ctx.op.getText();
        switch (op.charAt(0)) {
            case '+': return new Add(left, right);
            case '-': return new Sub(left, right);
            default: throw new IllegalArgumentException("Unknown operator " + op);
        }
    }


    @Override
    public Expression visitAtomExpr(ExpressionGrammarParser.AtomExprContext ctx) {
        return new Number(Integer.valueOf(ctx.getText()));
    }

    @Override
    public Expression visitParenExpr(ExpressionGrammarParser.ParenExprContext ctx) {
        return this.visit(ctx.expr());
    }
   
}
