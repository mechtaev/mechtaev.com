package pku_softeng;

public interface Expression {
    public int calculate();
    public void accept(Visitor visitor);
    public void accept(MemoVisitor visitor);
}
