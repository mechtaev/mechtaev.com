package pku_softeng;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedOutputStream;

public class Seq implements Command {
    Command left;
    Command right;

    @Override
    public void eval(InputStream input, OutputStream output) {
        left.eval(input, output);
        right.eval(null, output);
    }
    
}
