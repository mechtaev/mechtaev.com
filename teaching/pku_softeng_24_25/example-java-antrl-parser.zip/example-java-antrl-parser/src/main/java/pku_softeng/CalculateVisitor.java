package pku_softeng;

import java.util.Stack;

public class CalculateVisitor implements Visitor {
    public Stack<Integer> values = new Stack<>();

    @Override
    public void visit(Add a) {
        a.left.accept(this);  
        a.right.accept(this); 
        int result = values.pop() + values.pop();
        values.push(result);
    }

    @Override
    public void visit(Sub s) {
        s.left.accept(this);  
        s.right.accept(this); 
        int result = values.pop() - values.pop();
        values.push(result);
        
    }

    @Override
    public void visit(Number n) {
        values.push((Integer)n.value);        
    }
    
}
