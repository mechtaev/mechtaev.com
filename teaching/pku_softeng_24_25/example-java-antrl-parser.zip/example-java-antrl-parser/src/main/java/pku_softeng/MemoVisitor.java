package pku_softeng;

public interface MemoVisitor {
    public boolean alreadyVisited(Expression a);
    public void visitAgain(Expression a);
    public void visit(Add a);
    public void visit(Sub s);
    public void visit(Number n);    
}
