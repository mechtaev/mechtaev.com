package pku_softeng;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.Test;

import static org.junit.Assert.*;

import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Scanner;

public class AntlrTest {
    public AntlrTest() {
    }

    @Test
    public void testAntlr() throws Exception {
        String expressionString = "3 - (1 + 2)";
        CharStream parserInput = CharStreams.fromString(expressionString); 
        ExpressionGrammarLexer lexer = new ExpressionGrammarLexer(parserInput);
        CommonTokenStream tokenStream = new CommonTokenStream(lexer);        
        ExpressionGrammarParser parser = new ExpressionGrammarParser(tokenStream);
        ParseTree tree = parser.expr();

        Expression expression = tree.accept(new ExpressionConverter());

        assertEquals(0, expression.calculate());
    }


    @Test
    public void testCalculate() {
        Expression expression = 
          new Sub(new Number(3), new Add(new Number(1), new Number(2)));
        CalculateVisitor visitor  = new CalculateVisitor();
        expression.accept(visitor);
        assertEquals((Integer)0, visitor.values.pop());
    }

    @Test
    public void testSharing() {
        Expression leaf = new Number(1);
        Expression root = new Add(leaf, leaf);
        for (int i=0; i<30; i++) {
            root = new Add(root, root);
        }
        CalculateMemoVisitor visitor  = new CalculateMemoVisitor();
        root.accept(visitor);
        //assertEquals((Integer)0, visitor.values.pop());
    }



}
