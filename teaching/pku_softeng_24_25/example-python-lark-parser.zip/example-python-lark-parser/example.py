import sys
from dataclasses import dataclass
from enum import Enum, auto
from abc import ABC, abstractmethod

from lark import Lark
from lark.visitors import Visitor_Recursive


# This class is not necessary. I have added it
# to make the code closer to the provided UML diagram
class Expression(ABC):

    @abstractmethod
    def eval(self):
        pass


@dataclass
class Add(Expression):
    left: Expression
    right: Expression

    def eval(self):
        return self.left.eval() + self.right.eval()


@dataclass
class Sub(Expression):
    left: Expression
    right: Expression

    def eval(self):
        return self.left.eval() - self.right.eval()


@dataclass
class Mul(Expression):
    left: Expression
    right: Expression

    def eval(self):
        return self.left.eval() * self.right.eval()
    

@dataclass
class Div(Expression):
    left: Expression
    right: Expression

    def eval(self):
        return self.left.eval() / self.right.eval()

@dataclass
class Neg(Expression):
    expr: Expression

    def eval(self):
        return - self.expr.eval()

@dataclass
class Num(Expression):
    value: int

    def eval(self):
        return self.value
    

expression_grammar = """
    ?start: product
        | start "+" product -> add
        | start "-" product -> sub
    ?product: atom
        | product "*" atom  -> mul
        | product "/" atom  -> div
    ?atom: NUMBER           -> number
         | "-" atom         -> neg
         | "(" start ")"
    %import common.NUMBER
    %import common.WS_INLINE
    %ignore WS_INLINE
"""


# It would have been easier to use Transfomer, but here I demonstrate
# Visitor, since it is a bit more common pattern for such libraries.
class ASTConstructor(Visitor_Recursive):
    def __init__(self):
        self.stack = []

    def number(self, t):
        self.stack.append(Num(int(t.children[0])))

    def mul(self, t):
        r = self.stack.pop()
        l = self.stack.pop()
        self.stack.append(Mul(l, r))

    def add(self, t):
        r = self.stack.pop()
        l = self.stack.pop()
        self.stack.append(Add(l, r))

    def sub(self, t):
        r = self.stack.pop()
        l = self.stack.pop()
        self.stack.append(Sub(l, r))

    def div(self, t):
        r = self.stack.pop()
        l = self.stack.pop()
        self.stack.append(Div(l, r))

    def neg(self, t):
        self.stack.append(Neg(self.stack.pop()))


def parse(s):
    tree = Lark(expression_grammar).parse(s)
    visitor = ASTConstructor()
    visitor.visit(tree)
    return visitor.stack.pop()


if __name__ == "__main__":
    s = sys.argv[1]
    print(f'{s} = {parse(s).eval()}')
