# Minimal Python Lark Example

First, install Lark dependencies:

    pip install -r requirements.txt

Execute the example using the following command:

    python example.py "1 + (3 - 2)"
    
