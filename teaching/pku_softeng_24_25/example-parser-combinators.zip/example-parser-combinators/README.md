# Minimal Parser Conbinator Example in Python

Execute this example as

    python example.py "1+2+5"
    
The code is taken from https://gdevanla.github.io/posts/write-a-parser-combinator-in-python.html

