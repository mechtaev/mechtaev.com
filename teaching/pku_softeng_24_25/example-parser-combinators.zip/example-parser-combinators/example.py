import sys
import operator
import typing as tp

ParserP = tp.Callable[[str], tp.Tuple[tp.Any, str]]

class ParserError(Exception):
    def __init__(self, msg, content):
        super().__init__(f"{msg}: {content}")

def parse(p: ParserP, s: str) -> tp.Tuple[tp.Any, str]:
    (a, s) = p(s)
    return (a, s)

def anyChar() -> ParserP:
    def func(s):
        return (s[0], s[1:])
    return func


def oneChar(c) -> ParserP:
    def func(s):
        if s[0] == c:
            return (s[0], s[1:])
        raise ParserError(f"Unexpected {s[0]}, expecting {c}", s)

    return func


def anyDigit() -> ParserP:
    def func(s):
        if s[0].isdigit():
            return (s[0], s[1:])
        raise ParserError(f"Expected digit, got {s[0]}", s)

    return func


# Generic Predicate Parser
def satisfy(pred_function: tp.Callable[["char"], bool]) -> ParserP:
    def func(s):
        if not s:
            raise ParserError("Empty string", "")
        if pred_function(s[0]):
            return (s[0], s[1:])
        raise ParserError(f"Unexpected condition", s)

    return func


def oneCharP(c) -> ParserP:
    return satisfy(lambda c1: c == c1)


def anyDigitP() -> ParserP:
    return satisfy(lambda c: c.isdigit())


def compose(p1: ParserP, p2: ParserP) -> ParserP:
    def func(s):
        (a, s1) = parse(p1, s)
        (b, s2) = parse(p2, s1)
        return ((a, b), s2)

    return func


def choice(p1: ParserP, p2: ParserP) -> ParserP:
    def func(s):
        try:
            return p1(s)
        except ParserError:
            return p2(s)
    return func


def mathOp(op):
    return satisfy(lambda c: c == op)

ParserF = tp.Callable[[tp.Any], ParserP]

def bind(p1: ParserP, pf: ParserF) -> ParserP:
    def func(s):
        (a, s1) = parse(p1, s)
        # call the passed in function to get the next parser `p2`. This function take an argument that was produced by the first parser `p1`
        p2 = pf(a)
        (b, s2) = parse(p2, s1)
        return (b, s2)

    return func


def mathOpP() -> ParserP:
    def f(op):
        if op == "+":
            return operator.add
        elif op == "-":
            return operator.sub
        elif op == "*":
            return operator.mul
        elif op == "/":
            return operator.floordiv

    plus = bind(mathOp("+"), lambda a: lambda s: (f(a), s))
    minus = bind(mathOp("-"), lambda a: lambda s: (f(a), s))
    mult = bind(mathOp("*"), lambda a: lambda s: (f(a), s))
    div = bind(mathOp("/"), lambda a: lambda s: (f(a), s))

    return choice(plus, choice(minus, choice(mult, div)))


def expression_or_digit():
    return choice(expression_2(), anyDigitP())

def expression_2():
    def func(s):
        (digit1, s1) = parse(anyDigitP(), s)
        (op, s2) = parse(mathOpP(), s1)
        (digit2, s3) = parse(expression_or_digit(), s2)
        return (op(int(digit1), int(digit2)), s3)

    return func


print(parse(expression_or_digit(), sys.argv[1]))
