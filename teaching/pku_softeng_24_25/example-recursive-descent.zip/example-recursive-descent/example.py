import sys
import re

# Lexer class
class Lexer:
    def __init__(self, input_text):
        self.tokens = re.findall(r'\d+|[()+\-]', input_text)
        self.position = 0

    def get_next_token(self):
        if self.position < len(self.tokens):
            token = self.tokens[self.position]
            self.position += 1
            return token
        return None  # End of input

    def peek(self):
        if self.position < len(self.tokens):
            return self.tokens[self.position]
        return None


# Parser class
class Parser:
    def __init__(self, lexer):
        self.lexer = lexer
        self.current_token = self.lexer.get_next_token()

    def consume(self):
        self.current_token = self.lexer.get_next_token()

    def parse_E(self):
        node = self.parse_T()
        while self.current_token in ('+', '-'):
            op = self.current_token
            self.consume()
            node = (op, node, self.parse_T())
        return node

    def parse_T(self):
        if self.current_token == '(':
            self.consume()  # Consume '('
            node = self.parse_E()
            if self.current_token == ')':
                self.consume()  # Consume ')'
                return node
            else:
                raise SyntaxError("Missing closing parenthesis")
        elif self.current_token.isdigit():
            node = int(self.current_token)  # Convert id (number) to integer
            self.consume()
            return node
        else:
            raise SyntaxError(f"Unexpected token: {self.current_token}")

    def parse(self):
        return self.parse_E()


# Example usage
if __name__ == "__main__":
    input_text = sys.argv[1]
    lexer = Lexer(input_text)
    parser = Parser(lexer)
    syntax_tree = parser.parse()
    print(syntax_tree)
