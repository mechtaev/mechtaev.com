# Minimal Example of Recursive Descent Parser

To execute the program:

    python example.py
